/* eslint-disable no-undef */

const backupStatus = {
  disabled: false,
};

MDS.init(function (msg) {
  if (msg.event === "inited") {
    // create schema
    MDS.sql(
      "CREATE TABLE IF NOT EXISTS backups (id bigint auto_increment, filename varchar(256), block varchar(256), timestamp TIMESTAMP)"
    );

    // Create the first back up on start of MiniDapp
    MDS.log("Assert table emptiness, create backup on truthy.");
    MDS.sql("SELECT COUNT(*) FROM backups", function (response) {
      const tableEmpty = response.response.count === 0;
      MDS.log(`Sql table count -> ${tableEmpty}`);

      if (tableEmpty) {
        const today = new Date();
        const fileName = `minima_backup_${today.getDay()}${today.getMonth()}${today.getFullYear()}_${today.getHours()}${today.getMinutes()}.bak`;
        MDS.log(`Creating a new backup file with name -> ${fileName}`);
        MDS.cmd(`backup file:${fileName} password:"auto"`, function (response) {
          MDS.log(JSON.stringify(response));
          if (response.status) {
            MDS.log("Backup has been created, inserting row into table");
            MDS.sql(
              `INSERT INTO backups (filename, block) VALUES(${response.backup.file}, ${response.backup.block})`
            );
          }
        });
      }
    });
  }
  if (msg.event === "MDS_TIMER_10SECONDS") {
    MDS.log("MDS 1 hour time in play.");
    if (backupStatus.disabled) {
      MDS.log("Backup is currently disabled.");
    }
    // do a last back up check

    MDS.log("Assert table emptiness, create backup on truthy.");
    MDS.sql("SELECT COUNT(*) FROM backups", function (response) {
      const tableEmpty = response.response.count === 0;
      MDS.log(`Sql table count -> ${tableEmpty}`);

      if (tableEmpty) {
        const today = new Date();
        const fileName = `minima_backup_${today.getDay()}${today.getMonth()}${today.getFullYear()}_${today.getHours()}${today.getMinutes()}.bak`;
        MDS.log(`Creating a new backup file with name -> ${fileName}`);
        MDS.cmd(`backup file:${fileName} password:"auto"`, function (response) {
          MDS.log(JSON.stringify(response));
          if (response.status) {
            MDS.log("Backup has been created, inserting row into table");
            MDS.sql(`INSERT INTO backups VALUES(filename, block)`);
          }
        });
      }

      if (!tableEmpty) {
        const today = new Date();
        const fileName = `minima_backup_${today.getDay()}${today.getMonth()}${today.getFullYear()}_${today.getHours()}${today.getMinutes()}.bak`;
        MDS.log(`Creating a new backup file with name -> ${fileName}`);
        MDS.cmd(`backup file:${fileName} password:"auto"`, function (response) {
          MDS.log(JSON.stringify(response));
          if (response.status) {
            MDS.log("Backup has been created, inserting row into table");
            MDS.sql(`UPDATE backups WHERE id=1 VALUES(filename, block)`);
          }
        });
      }
    });
  }
});

// SELECT * FROM news WHERE date >= now() + INTERVAL 1 DAY;
